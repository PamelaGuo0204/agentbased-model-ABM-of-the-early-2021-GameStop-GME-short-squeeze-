#!/usr/bin/env python
# coding: utf-8

################################
#! our model is based on ABM market model, I use some codes from: https://github.com/dcline1/MarketABM/blob/master/MarketABM.ipynb
# including some codes in class Reddit_agent, update_price(), initialize() and the validation


# ### Historical Returns

# In[9]:


from pylab import *
import numpy as np
import scipy.stats as stats
import statsmodels.api as sm
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
from __future__ import division
from collections import Iterable

import numpy as np
from pandas import Series
import random
from matplotlib import gridspec
# get_ipython().run_line_magic('matplotlib', 'inline')


# In[55]:

##download the GME price from the Yahoo
df = yf.download("GME", start="2020-12-01", end="2021-02-05")


# In[270]:


df['log_adj_close'] = np.log(df['Adj Close'])
r_hist = np.diff(df['log_adj_close'].tolist())
mu = np.mean(r_hist)
mu_a = mu * 45
mu_hist = mu_a


# In[165]:


df['price'] = df['Adj Close'] / df['Adj Close'][0]
df['price']
price = []
for i in range(len(df['price'])):
    price.append(df['price'][i])
plot(price,'k')
ylabel('Price')
xlabel('Time')




# ### Agent Based Model (ABM)

# ### build the hedge fund class

# In[12]:


class hedge_fund():
    def __init__(self):
        #the number of the fundamentalist
        self.number = 100
        #fundamental price
        self.fundamental_price = 1
        #short sell position 1:open short sell, 0:close short sell
        self.short_sell_position = 0
        self.price_at_the_sell_position = 0
        #current price
        self.current_price = 0
        #create arrays
        self.pt = np.array([0.5])
        self.last_pt = self.pt[-1]
        #constant parameters
        self.alpha = 0.88
        self.beta = 0.88
        self.lampta = 2.55
        self.mu = 1.2473915132016953
        self.T = 1000 # the number of traders the agent trasfer everyday
        self.time_short_sell = 0 # time when hedge fund open short sell
        self.time_close_short_sell # time when hedge fund close short sell
        #probability
        self.probability = 0.5
        #utility
        self.utility = 0
        
    def open_short_sell(self,price,t):
        self.short_sell_position = 1
        self.price_at_the_sell_position = price
        self.time_short_sell = t
    
    #prospect thoery
    def change_behavior(self,p_vec,t,p_next):
        #close the position now
        delta_t = t-self.time_short_sell
        price = p_vec[-1]
        total_price = 0
        for p in range(self.time_short_sell,len(p_vec)):
            total_price = total_price + p_vec[p]
            
        value1 = -self.lampta * (delta_t * self.T * price - self.T * total_price)#close
        #keep
        value2 = self.probability * (self.T * total_price) ** self.alpha -(1-self.probability) * self.lampta*(p_next*(delta_t+1)*self.T)**self.beta
        if value1<value2:
            self.short_sell_position = 1
        else:
            self.short_sell_position = 0


# ### Reddit Agent class

# In[203]:


class Reddit_agent:
    def __init__(self):
        self.Dt = 1./45     # 252 trading days in a year
        self.b = 0.1         # beta
        self.alpha = 6.9
        self.Nf = 100        # number of fundamentalist traders
        self.Nc = 100        # number of noise traders
        self.N = self.Nf + self.Nc     # total number of traders
        self.nu1 = 0.7/self.Dt    # parameter for optimist/pessimist transition probabilities
        self.nu2 = 0.003/self.Dt  # parameter for fundamentalist/noise trader transition probabilities
        self.buyers = zeros([1,self.N])
        self.sellers = zeros([1,self.N])
        self.traders = zeros([1,self.N])
        for i in range(self.N):
            if i < self.Nc:       # noise trader
                self.traders[0, i] = randint(0, 2)    # 0 (pessimist) or 1 (optimist)
            else:
                self.traders[0, i] = 2                # fundamentalist

        self.Np = len(self.traders[0, self.traders[0,:] == 0])  # pessimist = 0
        self.No = len(self.traders[0, self.traders[0,:] == 1])  # optimist = 1
        self.Nf = len(self.traders[0, self.traders[0,:] == 2])  # fundamentalist = 2
        self.Nc = self.Np + self.No
        
        self.Novec = [self.No]
        self.Npvec = [self.Np]
        self.Ncvec = [self.Nc]
        self.Nfvec = [self.Nf]
        
        self.optim = None
        self.pessim = None
        self.funda = None
        self.noise = None
        #probability
        self.p_op = 0
        self.p_po = 0
        self.p_fc = 0
        self.p_cf = 0
        
        self.x = (self.No - self.Np) / self.Nc
        self.xvec = [self.x]
        
    def observe(self):
        self.Novec.append(self.No)
        self.Npvec.append(self.Np)
        self.Ncvec.append(self.Nc)
        self.Nfvec.append(self.Nf)
        self.xvec.append(self.x)
    
    def change(self,p,pf):
        self.p_op = self.nu1*self.Dt*self.Np/self.Nc                 # probability that optimist switches to pessimist
        self.p_po = self.nu1*self.Dt*self.No/self.Nc                 # probability that pessimist switches to optimist
    
        self.optim = binomial(1, 1 - self.p_op, self.N)    # 1 - p_op is probability of staying an optimist
        self.pessim = binomial(1, self.p_po, self.N)       # p_po is probability of switching to optimist

        rho = abs(p-pf)/pf
        self.p_fc = self.nu2*self.Dt*exp(-self.alpha*rho)       # probability that fundamentalist switches to noise
        self.p_cf = self.nu2*self.Dt*(1 - exp(-self.alpha*rho)) # probability that noise switches to fundamentalist
    
        self.funda = binomial(1, self.p_cf, self.N)        # p_cf is probability of switching to fundamentalist  
        self.noise = binomial(1, self.p_fc, self.N)      
        
        for i in range(self.N):
            if self.traders[0, i] == 2:           # fundamentalist
                pass
                if self.noise[i] == 1 and self.Nf > 1:
                    self.traders[0, i] = randint(0, 2)  # switch to noise
                    self.Nf -= 1
            elif self.funda[i] == 1:              # noise trader switches to fundamentalist
                self.traders[0, i] = 2;           
            elif self.traders[0, i] == 1:         # optimist
                self.traders[0, i] = self.optim[i]
            else:                            # pessimist
                self.traders[0, i] = self.pessim[i]
    

        self.Nf = len(self.traders[0, self.traders[0,:] == 2])
        self.No = len(self.traders[0, self.traders[0,:] == 1])
        self.Np = len(self.traders[0, self.traders[0,:] == 0])
        self.Nc = self.Np + self.No
        if self.Np < 1:      # Np = 0 is an absorbing state, so implement reflecting boundary
            self.Np = 1
            self.No = self.Nc - 1
        if self.No < 1:      # No = 0 is an absorbing state, so implement reflecting boundary
            self.No = 1
            self.Np = self.Nc - 1
        self.x = (self.No - self.Np) / self.Nc
        
        self.observe()
        


# ### market environment

# In[204]:


def initialize():
    global agent,p, pf, t, pvec, pfvec, tvec
    global Tf, Tc, mu
    np.random.seed(123)
    agent = Reddit_agent()
    Tf = 10         # size of trades made by fundamentalist traders
    Tc = 5          # size of trades made by noise traders
    mu = mu_hist    # annual growth of pf - taken from historical returns above
    pf = 1.0
    p = pf
    
#     x = (agent.No - agent.Np) / agent.Nc
    t = 0.
    
    pvec = [p]
    pfvec = [pf]
#     xvec = [x]
    tvec = [t]
    
def step():
    global agent,p, pf, x, t, pvec, pfvec, tvec
    global Tf, Tc, mu
    pvec.append(p)
    pfvec.append(pf)
    tvec.append(t)
    
def update_price():
    global agent,p, pf, t, pvec, pfvec, tvec
    global Tf, Tc, mu
    drift = min(p * agent.b * agent.Nf * Tf * agent.Dt, 1.0) * (pf - p) # avoid numerical instability from Euler discretization
    shock = p * agent.b * (agent.Nc * Tc * agent.x) * agent.Dt
    np = p + drift + shock 

    agent.change(np,pf)

    npf = pf + mu*pf*agent.Dt
    
    t = t + 1
    
    p, pf = np, npf
    
    step()


# In[205]:


initialize()
for i in range(0,45):
    update_price()
    


# In[206]:


plot(tvec,pvec,'k',label = 'price')
plot(tvec,pfvec,label = 'pf',linewidth = 0.5)
# plot(tvec,price,label = 'true price',color = 'r')
xlabel('Time')
ylabel('Price')
legend()
show()


# In[267]:


result = []
for i in range(1,len(pvec)):
    result.append(log(pvec[i]/pvec[i-1]))
del(tvec[-1])
plot(tvec,result,linewidth = 0.5)
xlabel('Time')
ylabel('Returns')


# In[185]:


plot([x/y for x,y in zip(agent.Novec,agent.Ncvec)],'darkorange',label = 'Opt')
plot([x/y for x,y in zip(agent.Npvec,agent.Ncvec)],'m',label = 'Pess')
ylabel('% of Chartists')
legend(loc ='upper left')
plt.show()


# In[186]:


plot(agent.Nfvec,'c',label = 'Funda')
plot(agent.Ncvec,'dimgray',label = 'Chart')
ylabel('Number of traders')
legend(loc ='upper left')
plt.show()


# ### Validation

# #### real statistics
# calculate some real statistics

# In[227]:

sigma = np.std(r_hist)
sigma2 = np.var(r_hist)
skew = stats.skew(r_hist)
kurt = stats.kurtosis(r_hist)
cv_historica = sigma / mu
mu_h = mu
sigma_h = sigma
sigma2_h = sigma2
skew_h = skew
kurt_h = kurt

print('real Stats (daily log returns):')
print('Mean:\t\t\t', mu)
print('Std dev:\t\t', sigma)
print('Variance:\t\t', sigma2)
print('Skew:\t\t\t', skew)
print('Excess kurt:\t\t', kurt)
print('Variation coefficient:\t\t',cv_historica)
print()



# In[226]:


r_abm = diff(log(pvec))

mu_abm = np.mean(r_abm)
sigma_abm = np.std(r_abm)
sigma2_abm = np.var(r_abm)
skew_abm = stats.skew(r_abm)
kurt_abm = stats.kurtosis(r_abm)
cv = sigma_abm / mu_abm
print('Optimized daily return statistics:')
print('Mean:\t\t\t', mu_abm)
print('Std dev:\t\t', sigma_abm)
print('Variance:\t\t', sigma2_abm)
print('Skew:\t\t\t', skew_abm)
print('Excess kurt:\t\t', kurt_abm)
print('Variation coefficient:\t\t',cv)
print()

mu_abm_a = mu_abm * 45
sigma_abm_a = sigma_abm * np.sqrt(45)
sigma2_abm_a = sigma2_abm * 45

print('Annualized return statistics:')
print('Mean (mu):\t\t', mu_abm_a)             # should match mu_hist on average (i.e. if run many times and averaged)
print('Std dev (sigma):\t', sigma_abm_a)
print('Variance:\t\t', sigma2_abm_a)


# ### log returns

# #### historical

# In[266]:


#historical
plt.plot(r_hist, linewidth=1, color='red', label='A')
plt.ylabel('real Returns')
# plt.xlim(-100,4000)
# plt.ylim(-0.15, 0.15)
plt.show()


# In[220]:


plt.hist(r_hist, bins=100, color='red')
plt.ylabel('Historical Count Frequency')
plt.xlabel('Log Return')
plt.xlim(-1, 1)
plt.show()


# #### ABM

# In[269]:


plt.plot(r_abm, linewidth=1, label='C')
plt.ylabel('ABM Returns')
plt.xlabel('Time')
# plt.xlim(-100,4000)
# plt.ylim(-0.15, 0.15)


# In[221]:


plt.hist(r_abm, bins=100)
plt.ylabel('ABM Count Frequency')
plt.xlabel('Log Return')
xlim(-0.3,0.3)


# ### hurst

# In[261]:


# coding: utf-8



def calcHurst2(ts):

    if not isinstance(ts, Iterable):
        print ('error')
        return

    n_min, n_max = 2, len(ts)//3
    RSlist = []
    for cut in range(n_min, n_max):
        children = len(ts) // cut
        children_list = [ts[i*children:(i+1)*children] for i in range(cut)]
        L = []
        for a_children in children_list:
            Ma = np.mean(a_children)
            Xta = Series(map(lambda x: x-Ma, a_children)).cumsum()
            Ra = max(Xta) - min(Xta)
            Sa = np.std(a_children)
            rs = Ra / Sa
            L.append(rs)
        RS = np.mean(L)
        RSlist.append(RS)
    return np.polyfit(np.log(range(2+len(RSlist),2,-1)), np.log(RSlist), 1)[0]

calcHurst2(r_abm)

